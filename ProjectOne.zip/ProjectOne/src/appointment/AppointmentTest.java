package appointment;
import org.junit.Test;

public class AppointmentTest {
	@Test
	public void createAppointment() {
		Appointment test1 = new Appointment("1234465", new java.util.Date() ,"alexis alexander");
		System.out.println(test1);
	}

}
