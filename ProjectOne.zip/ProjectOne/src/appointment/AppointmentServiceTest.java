package appointment;
import java.util.Date;

import org.junit.Test;

import contact.Contact;
import contact.ContactService;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

public class AppointmentServiceTest {
	@Test
	public void testAdd()
	{
	AppointmentService as = new AppointmentService();
	Appointment test1 = new Appointment("2009436", new java.util.Date(),"724 Shilling Dr");
	assertEquals(true, as.addAppointment(test1));
	}

	@Test
	public void testDelete()
	{
	AppointmentService as = new AppointmentService();
	     
	Appointment test1 = new Appointment("2009436", new java.util.Date(), "724 Shilling Dr");
	Appointment test2 = new Appointment("1234567", new java.util.Date(), "122 Her World");
	Appointment test3 = new Appointment("000000", new java.util.Date(), "143 His World");

	as.addAppointment(test1);
	as.addAppointment(test2);
	as.addAppointment(test3);

	assertEquals(true, as.deleteAppointment("1234567"));
	assertEquals(false, as.deleteAppointment("0000000"));
	assertEquals(false, as.deleteAppointment("0000000"));
	}
}
