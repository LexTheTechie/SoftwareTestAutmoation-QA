package appointment;
import java.util.ArrayList;

import contact.Contact;

public class AppointmentService {
	private ArrayList<Appointment>appointments;
	
	public AppointmentService() {
		appointments = new ArrayList<>();
		
	}
	public boolean addAppointment(Appointment newAppointment) {
		boolean isAlreadyAppointment = false;
		for(Appointment appointment:appointments) {
			if(appointment.getAppointmentId().equalsIgnoreCase(newAppointment.getAppointmentId())) {
				isAlreadyAppointment = true;
				break;
			}
		}
			if(!isAlreadyAppointment) {
				appointments.add(newAppointment);
				return true;
			}
			else {
				return false;
			}
		
	}
	
	public boolean deleteAppointment(String appointmentId){
		boolean isDeleted = false;
		for(Appointment appointment:appointments) {
			if(appointment.getAppointmentId().equals(appointmentId)) {
				appointments.remove(appointment);
				isDeleted = true;
				break;
			}
			
			
		}
		return isDeleted;
			
	}
	
	

		
	}

