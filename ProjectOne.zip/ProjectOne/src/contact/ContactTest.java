package contact;
import org.junit.Test;

public class ContactTest{
	@Test
	public void createContact() {
		Contact test1 = new Contact("383555","Lexi","Alexander", "1234567899", "1222 Horseshoe dr");
			System.out.println(test1);
		
	
	}
	
}
