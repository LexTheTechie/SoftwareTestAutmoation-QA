package task;
import java.util.ArrayList;
import java.util.List;

public class TaskService {
	public static  ArrayList<Task>tasks;
	
	public TaskService() {
		tasks = new ArrayList<>();
		
	}
	public boolean addTask(Task  newTask) {
		boolean isAlreadyTask = false;
		for(Task task:tasks) {
			if(task.getTaskId().equalsIgnoreCase(newTask.getTaskId())) {
				isAlreadyTask = true;
				break;
			}
		}
			if(!isAlreadyTask) {
				tasks.add(newTask);
				return true;
			}
			else {
				return false;
			}
			
		
	}
	public boolean deleteTask(String taskId){
		boolean isDeleted = false;
		for(Task task:tasks) {
			if(task.getTaskId().equalsIgnoreCase(taskId)) {
				tasks.remove(task);
				isDeleted = true;
				break;
			}
		}
	return isDeleted;	
	}
	
			
			
		
		
			
	

	public boolean updateTask(String taskId, String name, String description) {
		
		boolean isUpdated = false;
		for(Task task:tasks) {
			if(task.getTaskId().equals(taskId)) {
				if(!name.equals("") && !(name.length()>20)) {
					task.setName(name);
				}
				if(!description.equals("") && !(description.length()>50)) {
					task.setDescription(description);
				}
				
					
			isUpdated = true;
			break;
					
				
			}
			
		}
		
			
		return isUpdated;}
}