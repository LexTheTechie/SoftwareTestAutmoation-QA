package task;

import org.junit.Test;
import org.junit.Before;
import org.junit.Assert;

public class TaskTest {
		@Test
		public void createContact() {
			Task test1 = new Task("12345678","JUNIT test","Perform JUNIT Test");
				System.out.println(test1);
			Task test2 = new Task("3836455","AALEXANDER test","Perform JUNIT Test2");
				System.out.println(test2);
			Task test3 = new Task("4013555","SOFTTEST test","Perform JUNIT Test3");
				System.out.println(test3);
		
			
		
		}
		
		
		
	}


