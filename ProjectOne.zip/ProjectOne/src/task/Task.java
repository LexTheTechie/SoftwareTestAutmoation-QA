package task;
import java.util.Comparator;

public class Task {
	private String taskId;
	private String name;
	private String description;
	
	public Task(String taskId, String name, String description){
		super();
		this.taskId = taskId;
		this.name = name;
		this.description = description;
	}
	public String getTaskId(){
		return taskId;
	}
	
	public void setTaskId(String taskId){
		this.taskId = taskId;
	
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;

	}
	public String getDescription(){
		return description;
	}
	
	public void setDescription(String description){
		this.description = description;
	}
	 @Override
	    public boolean equals(Object obj) {
	        if (this == obj)
	            return true;

	        if (obj == null)
	            return false;

	        if (this.getClass() != obj.getClass())
	            return false;

	        Task t = (Task) obj;
	        return getTaskId().equals(t.getTaskId());
	    }
	  public static Comparator<Task> compareById = new Comparator<Task>() {
	        @Override
	        public int compare(Task t1, Task t2) {
	            return t1.getTaskId().compareTo(t2.getTaskId());
	        }
	    };
	@Override
	   public String toString() {
	       return "Task [taskId=" + taskId + ", name =" + name + ", description=" + description + "]";
	   }
 
	
}
