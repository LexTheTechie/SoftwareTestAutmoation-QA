package task;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import task.Task;
import task.TaskService;

public class TaskServiceTest {
	@Test
	public void testAdd()
	{
	TaskService ts = new TaskService();
	Task test1 = new Task("2009436", "Lex", "Alexander");
	Task test2 = new Task("1234567", "JUNIT TEST", "alexander");
	assertEquals(true, ts.addTask(test1));
	assertEquals(true, ts.addTask(test2));
	}

	@Test
	public void testDelete()
	{
	   TaskService ts = new TaskService();
	     
	Task test1 = new Task("2009436", "Lex", "Alexander");
	Task test2 = new Task("1234567", "Tuffy", "Alexander");
	Task test3 = new Task("000000", "Tater", "Beck");

	ts.addTask(test1);
	ts.addTask(test2);
	ts.addTask(test3);
	
	assertEquals(true, ts.deleteTask("2009436"));
	assertEquals(false, ts.deleteTask("0000"));


	}

	@Test
	public void testUpdate()
	{
	TaskService cs = new TaskService();
	Task test1 = new Task("2008436", "Lex", "Alexander");
	Task test2 = new Task("1235567", "Tuffy", "Alexander");
	Task test3 = new Task("00011000", "Tater", "Beck");


	cs.addTask(test1);
	cs.addTask(test2);
	cs.addTask(test3);

	assertEquals(true, cs.updateTask("2008436", "TaterFirst", "BeckLast"));
	assertEquals(false, cs.updateTask("000001", "TaterFirst", "BeckLast"));
	
	}

}
